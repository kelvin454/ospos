<?php 

$lang["datepicker_all_time"] = "Sve";
$lang["datepicker_apply"] = "Primjeni";
$lang["datepicker_cancel"] = "Otkaži";
$lang["datepicker_custom"] = "Slobodan izbor";
$lang["datepicker_from"] = "Od";
$lang["datepicker_last_30"] = "Zadnjih 30 dana";
$lang["datepicker_last_7"] = "Zadnjih 7 dana";
$lang["datepicker_last_financial_year"] = "";
$lang["datepicker_last_month"] = "Zadnji mjesec";
$lang["datepicker_last_year"] = "Zadnja godina";
$lang["datepicker_same_month_last_year"] = "Ovaj mjesec prošle godine";
$lang["datepicker_same_month_to_same_day_last_year"] = "Ovaj mjesec do danas prošle godine";
$lang["datepicker_this_financial_year"] = "";
$lang["datepicker_this_month"] = "Ovaj mjesec";
$lang["datepicker_this_year"] = "Ova godina";
$lang["datepicker_to"] = "Do";
$lang["datepicker_today"] = "Danas";
$lang["datepicker_today_last_year"] = "Ovaj dan prošle godine";
$lang["datepicker_weekstart"] = "1";
$lang["datepicker_yesterday"] = "Jučer";
