<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');                                                                                                                                            
$config['default_email_address'] = "";
$config['default_cc_address'] = '';
$config['default_sender_name'] = "";
$config['default_sender_address'] = "";
$config['default_bounce_address'] = "";
$config['charset'] = 'utf-8';
$config['mailtype'] = 'html';
$config['wordwrap'] = FALSE;

