<?php 

$lang["login_gcaptcha"] = "I'm not a robot.";
$lang["login_go"] = "Go";
$lang["login_invalid_gcaptcha"] = "Please verify that you are not a robot.";
$lang["login_invalid_installation"] = "The installation is not correct, check your php.ini file.";
$lang["login_invalid_username_and_password"] = "Invalid username and/or password.";
$lang["login_login"] = "Login";
$lang["login_logout"] = "Logout";
$lang["login_migration_needed"] = "A database migration to %1 will start after login.";
$lang["login_password"] = "Password";
$lang["login_username"] = "Username";
$lang["login_welcome"] = "Welcome to %1!";
