<?php 

$lang["datepicker_all_time"] = "Bütün vaxta";
$lang["datepicker_apply"] = "Uygula";
$lang["datepicker_cancel"] = "İmtina";
$lang["datepicker_custom"] = "Fərqli";
$lang["datepicker_from"] = "Bundan";
$lang["datepicker_last_30"] = "Son 30 gün";
$lang["datepicker_last_7"] = "Son 7 Gün";
$lang["datepicker_last_financial_year"] = "Son Maliyyə ili";
$lang["datepicker_last_month"] = "Ötən ay";
$lang["datepicker_last_year"] = "Ötən il";
$lang["datepicker_same_month_last_year"] = "Ötən il eyni ay";
$lang["datepicker_same_month_to_same_day_last_year"] = "Ötən ilin eyni ayindan";
$lang["datepicker_this_financial_year"] = "Cari maliyyə ili";
$lang["datepicker_this_month"] = "Bu ay";
$lang["datepicker_this_year"] = "Bu il";
$lang["datepicker_to"] = "Buna";
$lang["datepicker_today"] = "Bugün";
$lang["datepicker_today_last_year"] = "Keçən il bu gün";
$lang["datepicker_weekstart"] = "0";
$lang["datepicker_yesterday"] = "Dünən";
