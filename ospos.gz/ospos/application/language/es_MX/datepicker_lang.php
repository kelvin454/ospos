<?php 

$lang["datepicker_all_time"] = "Todo";
$lang["datepicker_apply"] = "Aplicar";
$lang["datepicker_cancel"] = "Cancelar";
$lang["datepicker_custom"] = "Personalizar";
$lang["datepicker_from"] = "Desde";
$lang["datepicker_last_30"] = "Últimos 30 días";
$lang["datepicker_last_7"] = "Últimos 7 días";
$lang["datepicker_last_financial_year"] = "Último año fiscal";
$lang["datepicker_last_month"] = "Mes pasado";
$lang["datepicker_last_year"] = "Año pasado";
$lang["datepicker_same_month_last_year"] = "Mismo mes del año pasado";
$lang["datepicker_same_month_to_same_day_last_year"] = "Mismo mes al mismo día del año pasado";
$lang["datepicker_this_financial_year"] = "Año fiscal actual";
$lang["datepicker_this_month"] = "Mes actual";
$lang["datepicker_this_year"] = "Año actual";
$lang["datepicker_to"] = "Hasta";
$lang["datepicker_today"] = "Hoy";
$lang["datepicker_today_last_year"] = "Hoy, del año pasado";
$lang["datepicker_weekstart"] = "0";
$lang["datepicker_yesterday"] = "Ayer";
