<?php 

$lang["messages_first_name"] = "Ime";
$lang["messages_last_name"] = "Prezime";
$lang["messages_message"] = "Poruka";
$lang["messages_message_placeholder"] = "Vaša poruka ovdje ...";
$lang["messages_message_required"] = "Poruka je obavezna";
$lang["messages_multiple_phones"] = "(U slučaju više primalaca, unesite mobilne brojeve odvojene zarezima)";
$lang["messages_phone"] = "Telefonski broj";
$lang["messages_phone_number_required"] = "Broj telefona je obavezan";
$lang["messages_phone_placeholder"] = "Broj mobilnog telefona ovde...";
$lang["messages_sms_send"] = "Pošalji SMS";
$lang["messages_successfully_sent"] = "Poruka je uspješno poslata: ";
$lang["messages_unsuccessfully_sent"] = "Poruka nije uspešno poslata: ";
