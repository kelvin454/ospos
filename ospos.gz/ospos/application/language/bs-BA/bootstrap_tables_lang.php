<?php 

$lang["tables_all"] = "Sve";
$lang["tables_columns"] = "Kolone";
$lang["tables_hide_show_pagination"] = "Sakrij / prikaži paginaciju";
$lang["tables_loading"] = "Učitavanje sačekajte...";
$lang["tables_page_from_to"] = "Prikazivanje {0} do {1} od {2} redova";
$lang["tables_refresh"] = "Osvježi";
$lang["tables_rows_per_page"] = "{0} redova po stranici";
$lang["tables_toggle"] = "Promijeni prikaz";
