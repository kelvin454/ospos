<?php 

$lang["category_name_required"] = "שם קטגורית הוצאה נדרש";
$lang["expenses_categories_add_item"] = "הוסף קטגוריה";
$lang["expenses_categories_cannot_be_deleted"] = "לא ניתן למחוק קטגוריית הוצאה(ות)";
$lang["expenses_categories_category_id"] = "מזהה";
$lang["expenses_categories_confirm_delete"] = "האם אתה בטוח שברצונך למחוק את קטגוריית ההוצאה שנבחרה?";
$lang["expenses_categories_confirm_restore"] = "האם אתה בטוח שברצונך לשחזר את קטגוריית ההוצאה שנבחרה?";
$lang["expenses_categories_description"] = "תיאור קטגוריה";
$lang["expenses_categories_error_adding_updating"] = "שגיאה בהוספה / עדכון של תיאור קטגוריה";
$lang["expenses_categories_info"] = "מידע על תיאור קטגוריה";
$lang["expenses_categories_name"] = "שם קטגוריה";
$lang["expenses_categories_new"] = "קטגוריה חדשה";
$lang["expenses_categories_no_expenses_categories_to_display"] = "אין קטגוריה להצגה";
$lang["expenses_categories_none_selected"] = "לא בחרת כל קטגורית הוצאה";
$lang["expenses_categories_one_or_multiple"] = "קטגוריה הוצאה";
$lang["expenses_categories_quantity"] = "כמות";
$lang["expenses_categories_successful_adding"] = "סוג הוצאה נוסף בהצלחה";
$lang["expenses_categories_successful_deleted"] = "סוג הוצאה נמחק בהצלחה";
$lang["expenses_categories_successful_updating"] = "סוג הוצאה עודכן בהצלחה";
$lang["expenses_categories_update"] = "עדכון קטגוריה";
