<?php
$lang["login_gcaptcha"] = "Je ne suis pas un robot.";
$lang["login_go"] = "Lancer";
$lang["login_invalid_gcaptcha"] = "Veuillez vérifier que vous n'êtes pas un robot.";
$lang["login_invalid_installation"] = "Cette installation est incorrecte, veuillez vérifier votre fichier php.ini.";
$lang["login_invalid_username_and_password"] = "Nom d'utilisateur et/ou mot de passe invalide.";
$lang["login_login"] = "Login";
$lang["login_logout"] = "Déconnexion";
$lang["login_migration_needed"] = "Une migration de base de données vers %1 débutera après l'ouverture de session.";
$lang["login_password"] = "Mot de passe";
$lang["login_username"] = "Nom d'utilisateur";
$lang["login_welcome"] = "Bienvenue à %1 !";
