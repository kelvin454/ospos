<?php 

$lang["login_gcaptcha"] = "No soy un robot.";
$lang["login_go"] = "Ir";
$lang["login_invalid_gcaptcha"] = "Por favor verifique si usted no es un robot.";
$lang["login_invalid_installation"] = "La instalación no es correcta, comprueba el fichero php.ini.";
$lang["login_invalid_username_and_password"] = "Usuario y/o Contraseña no validos.";
$lang["login_login"] = "Iniciar Sesión";
$lang["login_logout"] = "Cerrar sesión";
$lang["login_migration_needed"] = "La migración de la base de datos a %1 se iniciará después del inicio de sesión.";
$lang["login_password"] = "Contraseña";
$lang["login_username"] = "Usuario";
$lang["login_welcome"] = "Bienvenido a %1!";
