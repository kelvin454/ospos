<?php
$lang["login_gcaptcha"] = "Ja nisam robot.";
$lang["login_go"] = "Idi";
$lang["login_invalid_gcaptcha"] = "Molimo potvrdite da niste robot.";
$lang["login_invalid_installation"] = "Instalacija nije ispravna, provjerite vašu php.ini datoteku.";
$lang["login_invalid_username_and_password"] = "Pogrešno korisničko ime i/ili lozinka.";
$lang["login_login"] = "Prijava";
$lang["login_logout"] = "Odjava";
$lang["login_migration_needed"] = "Migracija baze podataka na %1 će početi nakon prijavljivanja.";
$lang["login_password"] = "Lozinka";
$lang["login_username"] = "Korisničko ime";
$lang["login_welcome"] = "Dobrodošli u %1!";
