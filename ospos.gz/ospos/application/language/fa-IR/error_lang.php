<?php 

$lang["error_no_permission_module"] = "شما اجازه دسترسی به ماژول به نام خود را ندارید";
$lang["error_unknown"] = "خطای غیر منتظره";
