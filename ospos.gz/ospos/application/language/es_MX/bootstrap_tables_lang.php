<?php 

$lang["tables_all"] = "Todos";
$lang["tables_columns"] = "Columnas";
$lang["tables_hide_show_pagination"] = "Ocultar/Mostrar paginación";
$lang["tables_loading"] = "Cargando, por favor espere...";
$lang["tables_page_from_to"] = "Mostrando de {0} a {1} de {2} registros";
$lang["tables_refresh"] = "Actualizar";
$lang["tables_rows_per_page"] = "{0} registros por página";
$lang["tables_toggle"] = "Establecer";
