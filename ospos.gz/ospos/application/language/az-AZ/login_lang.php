<?php
$lang["login_gcaptcha"] = "Mən robot deyiləm.";
$lang["login_go"] = "daxil ol";
$lang["login_invalid_gcaptcha"] = "Robot olmadığınızı təsdiqləyin.";
$lang["login_invalid_installation"] = "Quraşdırma düzgün deyil, php.ini faylını yoxlayın.";
$lang["login_invalid_username_and_password"] = "Yanlış istifadəçi adı və ya şifrə.";
$lang["login_login"] = "Giriş";
$lang["login_logout"] = "Çıxış";
$lang["login_migration_needed"] = "%1 -ə daxil olandan sonra verilənlər bazası miqrasiyası başlayacaq.";
$lang["login_password"] = "Şifrə";
$lang["login_username"] = "İstifadəçi";
$lang["login_welcome"] = "%1 -ə xoş gəlmisiniz!";
