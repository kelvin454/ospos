<?php 

$lang["enum_half_down"] = "Mitad abajo";
$lang["enum_half_even"] = "Mitad par";
$lang["enum_half_five"] = "Cinco y media";
$lang["enum_half_odd"] = "Mitad impar";
$lang["enum_half_up"] = "Medio arriba";
$lang["enum_round_down"] = "Truncado";
$lang["enum_round_up"] = "Redondeo arriba";
