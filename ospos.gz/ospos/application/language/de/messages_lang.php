<?php 

$lang["messages_first_name"] = "Vorname";
$lang["messages_last_name"] = "Nachname";
$lang["messages_message"] = "Nachricht";
$lang["messages_message_placeholder"] = "Ihre Nachricht hier …";
$lang["messages_message_required"] = "Nachricht ist ein Pflichtfeld";
$lang["messages_multiple_phones"] = "(Im Falle von mehreren Handynummern diese bitte mit Kommas getrennt hier eingeben)";
$lang["messages_phone"] = "Handynummer";
$lang["messages_phone_number_required"] = "Handynummer ist ein Pflichtfeld";
$lang["messages_phone_placeholder"] = "Handy-Nummer(n) hier.....";
$lang["messages_sms_send"] = "SMS Senden";
$lang["messages_successfully_sent"] = "Nachricht erfolgreich gesendet an: ";
$lang["messages_unsuccessfully_sent"] = "Nachricht NICHT erfolgreich gesendet an: ";
